<?php include('header.php');?>
<div style="text-align:center;
    background: #fafcff;"><img style="width:550px; 
    margin: 0px auto;" src="<?=base_url()?>salon_assets/images/other/dashboard.jpg" class="img-responsive"></div>
	
<?php include('footer.php');?>