<!DOCTYPE html>
<html>
<head>
	
</head>
<body>
<?php


?>
	<h1>Contact No</h1>

	<div>
		<h2>Business Department</h2>
		<p>(+91) 8087279032</p>

		<h2>HR Department</h2>
		<p>(+91) 9307057897</p>
	</div>

	<div>
		<h2>Location</h2>
		<p><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3782.190393497935!2d73.91112337519279!3d18.565453182536878!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc2c74408d47851%3A0x31be7a30d613c852!2sQuickensol%20IT%20Solutions%20LLP!5e0!3m2!1sen!2sin!4v1695192492547!5m2!1sen!2sin" width="300" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></p>
		<p>Office No. 306, Sky Max, Konark Nagar, Clover Park, Viman Nagar, Pune, Maharashtra-411014, India</p>
	</div>

	<div>
		<h2>Email Us</h2>
		<p>info@quickensol.com</p>
	</div>
</body>
</html>