ALTER TABLE `tbl_salon_emp_service` CHANGE `status` `status` ENUM('0','1') CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT '0';
